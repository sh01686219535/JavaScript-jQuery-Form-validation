// function checkFirstName(){
// 	var firstNameValue = $("#firstName").val();	
// 	var regExp = /^[a-zA-Z\.\' ']{3,30}$/
// 	if (regExp.test(firstNameValue)) {
// 		$("#firstNameError").text(" ");
// 		return true;
// 	}else{
// 		$("#firstNameError").text("First Name only 3 to 30 characters");
// 		return false;
// 	}
// };
// $("#firstName").keyup(function() {
// 	checkFirstName();
// });
// // End FirstName
// function checkLastname(){
// 	var lastNameValue = $("#lastName").val();
// 	var regExp = /^[a-zA-Z.\' ']{3,10}$/
// 	if (regExp.test(lastNameValue)) {
// 		$("#lsatNameError").text(" ");
// 		return true;
// 	}else{
// 		$("#lsatNameError").text(" First Name only 3 to 10 characters");
// 		return false;
// 	}
// };
// $("#lastName").keyup(function(){
// 	checkLastname();
// });
// //End LastName
// function checkEmail(){
// 	var emailValue= $("#email").val();
// 	var regExp = /^([a-zA-Z0-9_\-\.])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z]{2,10})$/
// 	if (regExp.test(emailValue)) {
// 		$("#emailError").text(" ");
// 		return true;
// 	}else{
// 		$("#emailError").text(" Invalid email address");		
// 		return false;
// 	}
// };
// $("#email").keyup(function(){
// 	checkEmail();
// });
// //End Email
// function checkPassword(){
// 	var passwordValue = $("#passWord").val();
// 	var regExp = /^([A-Z]{1})+([a-z]{1})+([0-9]{1})+([@#$%^&]{1})+([pqxyz]{1})+([a-zA-Z0-9]{3})$/
// 	if (regExp.test(passwordValue)) {
// 		$("#passwordError").text(" ");
// 		return true;
// 	}else{
// 		$("#passwordError").text(" Password (A-Za-z0-9@#$%^&pwxyz a-zA-Z0-9) length 6 to 25 digit");
// 		return false;
// 	}
// } ;
// $("#passWord").keyup(function(){
// 	checkPassword()
// });
// //End Pasword
// function checkConfirmPassword(){
// 	var confirmPassword = $("#confirmPassword").val();
// 	var passwordValue = $("#passWord").val();
// 	if (confirmPassword == passwordValue) {
// 		$("#confirmPasswordError").text(" ");
// 		return true;
// 	}else{
// 		$("#confirmPasswordError").text(" Confirm Password not match");
// 		return false;
// 	}
// }
// $("#confirmPassword").keyup(function(){
// 	checkConfirmPassword();
// });
// $("#register").submit(function() {
// 	if(checkFirstName() == true && checkLastname() == true && checkEmail() == true && checkPassword() == true && checkConfirmPassword() == true){
// 		return true;
// 	}else{
// 		return false;
// 	}
// });


//With Javascript
function first(){
	var firstNameValue = document.getElementById("firstName").value;
	var rexExp = /^[a-zA-Z_\.\-\" "]{3,30}$/
	if (rexExp.test(firstNameValue)) {
		document.getElementById("firstNameError").innerHTML=" ";
		return true;
	}else{
		document.getElementById("firstNameError").innerHTML=" First Name only 3 to 30 characters";
		return false;
	}
};
function last(){
	var lastNameValue = document.getElementById("lastName").value;
	var rexExp = /^[a-zA-Z_\.\-\" "]{3,10}$/
	if (rexExp.test(lastNameValue)) {
		document.getElementById("lsatNameError").innerHTML=" ";
		return true;
	}else{
		document.getElementById("lsatNameError").innerHTML=" Last Name only 3 to 30 characters";
		return false;
	}
};
function Email(){
	var emailValue = document.getElementById("email").value;
	var rexExp = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z]{2,12})$/
	if (rexExp.test(emailValue)) {
		document.getElementById("emailError").innerHTML=" ";
		return true;
	}else{
		document.getElementById("emailError").innerHTML=" Invalid email address";
		return false;
	}
};
function Password(){
	var passWordValue = document.getElementById("passWord").value;
	var rexExp = /^([A-Z]{1})+([a-z]{1})+([0-9]{1})+([@#$%^&*]{1})+([pqxyz]{1})+([a-zA-Z0-9]{3})$/
	if (rexExp.test(passWordValue)) {
		document.getElementById("passwordError").innerHTML=" ";
		return true;
	}else{
		document.getElementById("passwordError").innerHTML=" Password (A-Za-z0-9@#$%^&pwxyz a-zA-Z0-9) length 6 to 25 digit";
		return false;
	}
};
function Confirmpassword(){
	var ConfirmpasswordValue = document.getElementById("confirmPassword").value;
	var passWordValue = document.getElementById("passWord").value;
	if (passWordValue == ConfirmpasswordValue) {
		document.getElementById("confirmPasswordError").innerHTML=" ";
		return true;
	}else{
		document.getElementById("confirmPasswordError").innerHTML=" Confirm Password not match";
		return false;
	}
};
function validation(){
	if (first() == true && last() == true && Email() == true && Password() == true && Confirmpassword() == true) {
		return true;
	}else{
		return false;
	}
};